"""Task 1: identify the data of the milk payment problem and compare two designs.

FAT_RATE and SNF_RATE here are illustrative per-percentage-point rates used only
for the comparison of Design A (list of tuples) and Design B (separate variables).
"""
import time

# ---------- named constants (never change during a run) ----------
FAT_RATE = 5.00
SNF_RATE = 3.00
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 7.0, 10.0
DAYS = 10
SHIFTS = ("M", "E")
MAX_FARMERS = 300

# ---------- 1. data items and their types ----------
print("1. Data items and types")
sample = ("F001", 12.5, 4.2, 8.5, "M")
names = ("farmer_id", "litres", "fat", "snf", "shift")
for name, value in zip(names, sample):
    print(f"   {name:<10}{value!r:<8}{type(value).__name__}")
print("   counts (entries, days) are int:", type(DAYS).__name__)

# ---------- 2. rules every payment must satisfy ----------
def broken_rules(farmer_id, litres, fat, snf, shift):
    """Return a list of the rules that the entry breaks (empty list = valid)."""
    broken = []
    if farmer_id == "":
        broken.append("farmer ID empty")
    if litres <= 0:
        broken.append("litres must be > 0")
    if not MIN_FAT <= fat <= MAX_FAT:
        broken.append("fat outside 2.0 - 7.0")
    if not MIN_SNF <= snf <= MAX_SNF:
        broken.append("snf outside 7.0 - 10.0")
    if shift not in SHIFTS:
        broken.append("shift not M or E")
    return broken

print("\n2. Rule check on sample entries")
tests = [("F001", 12.5, 4.2, 8.5, "M"), ("F002", -3.0, 4.2, 8.5, "M"),
         ("F003", 10.0, 7.9, 8.5, "E"), ("F004", 10.0, 4.0, 6.0, "E"),
         ("F005", 10.0, 4.0, 8.5, "X"), ("", 10.0, 4.0, 8.5, "M")]
for entry in tests:
    print("  ", entry, "->", broken_rules(*entry) or "valid")

# ---------- 3. Design A versus Design B for n farmers ----------
def design_a_total(entries):
    total = 0.0
    for litres, fat, snf in entries:
        total += litres * (fat * FAT_RATE + snf * SNF_RATE)
    return total

def make_entries(n):
    return [(10.0 + i % 10, 3.0 + (i % 30) / 10, 8.0 + (i % 15) / 10) for i in range(n)]

def design_b_source(entries):
    """Build the program text that Design B (separate variables) would need."""
    lines = []
    for i, (litres, fat, snf) in enumerate(entries, start=1):
        lines.append(f"litres{i}, fat{i}, snf{i} = {litres}, {fat}, {snf}")
    for i in range(1, len(entries) + 1):
        lines.append(f"amount{i} = litres{i} * (fat{i} * FAT_RATE + snf{i} * SNF_RATE)")
    lines.append("total = " + " + ".join(f"amount{i}" for i in range(1, len(entries) + 1)))
    return "\n".join(lines)

print("\n3. Design A (list of tuples) versus Design B (separate variables)")
n = MAX_FARMERS
entries = make_entries(n)
source_b = design_b_source(entries)
namespace = {"FAT_RATE": FAT_RATE, "SNF_RATE": SNF_RATE}
t = time.perf_counter()
exec(source_b, namespace)
time_b = time.perf_counter() - t
t = time.perf_counter()
total_a = design_a_total(entries)
time_a = time.perf_counter() - t
print(f"   n = {n} farmers")
input_vars = [k for k in namespace
              if any(k.startswith(p) and k[len(p):].isdigit() for p in ("litres", "fat", "snf"))]
print(f"   Design B: {len(source_b.splitlines())} lines of code, "
      f"{len(input_vars)} input variables created")
print("   Design A: 4 lines of code (loop), 1 list")
print(f"   totals equal: {total_a == namespace['total']}  (total = {total_a:.2f})")
print(f"   time A = {time_a*1e6:.1f} microseconds, time B = {time_b*1e6:.1f} microseconds (includes compile)")

print("\n   Design A time for growing n (same 4 lines of code each time):")
for size in (300, 3000, 30000, 300000):
    data = make_entries(size)
    t = time.perf_counter()
    design_a_total(data)
    dt = time.perf_counter() - t
    print(f"   n = {size:>7}: {dt*1000:8.3f} ms")
