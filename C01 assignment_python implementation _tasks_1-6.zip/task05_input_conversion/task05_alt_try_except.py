"""Task 5 alternative: try / except ValueError instead of checking the text first."""
import timeit

def is_valid_number(text):
    return text.strip().replace(".", "", 1).isdigit()

def convert_check_first(text):
    """Return a float, or None when the text is not a plain number."""
    if not is_valid_number(text):
        return None
    return float(text)

def convert_try_except(text):
    """Return a float, or None when float() raises ValueError."""
    try:
        return float(text)
    except ValueError:
        return None

samples = ["8,5", " 8.5 ", "eight", "8.5", "1e3", "nan", "-5"]
print(f"{'typed text':<12}{'check first':<14}{'try/except':<12}")
for text in samples:
    print(f"{text!r:<12}{convert_check_first(text)!s:<14}{convert_try_except(text)!s:<12}")

print("\nTime per entry (500,000 calls each)")
n = 500_000
for text in ("8.5", "eight"):
    for label, func in (("check first", convert_check_first), ("try/except", convert_try_except)):
        t = timeit.timeit(lambda: func(text), number=n) / n
        print(f"  input {text!r:<8} {label:<12}{t*1e9:8.1f} ns")
