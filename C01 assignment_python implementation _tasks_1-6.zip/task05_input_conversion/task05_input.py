"""Task 5: read the clerk's entries, validate them before converting, print aligned results.

Run with the input file:   python task05_input.py < input.txt
(When input comes from a file, each typed answer is echoed so the output reads like a session.)
"""
import sys

BASE_RATE, FAT_STEP_VALUE, SNF_STEP_VALUE = 30.0, 0.40, 0.30
STANDARD_FAT, STANDARD_SNF, STEP = 3.5, 8.5, 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 7.0, 10.0


def ask(prompt):
    """input() that also echoes the answer when the input comes from a file."""
    text = input(prompt)
    if not sys.stdin.isatty():
        print(text)
    return text


def is_valid_number(text):
    """Return True if text looks like a non-negative number such as 8 or 8.5."""
    text = text.strip()
    return text.replace(".", "", 1).isdigit()


def read_number(prompt, low, high):
    """Keep asking until the clerk enters a number between low and high."""
    while True:
        text = ask(prompt).strip()
        if not is_valid_number(text):
            print("  Invalid number. Use digits and one decimal point, e.g. 8.5")
            continue
        value = float(text)
        if low <= value <= high:
            return value
        print(f"  Value must be between {low} and {high}.")


def rate_per_litre(fat, snf):
    fat_steps = round((fat - STANDARD_FAT) / STEP)
    snf_steps = round((snf - STANDARD_SNF) / STEP)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)


print("Why input() returns text:")
text = "8.5"
print("  type of typed text:", type(text).__name__, "| float(text) =", float(text),
      "| int('8') =", int("8"))
for bad in ("8.5", "8,5", "eight"):
    try:
        int(bad)
    except ValueError as error:
        print(f"  int({bad!r}) -> ValueError: {error}")
for bad in ("8,5", "eight"):
    try:
        float(bad)
    except ValueError as error:
        print(f"  float({bad!r}) -> ValueError: {error}")

print("\nEnter three deliveries")
rows = []
for number in (1, 2, 3):
    print(f"\nEntry {number}")
    farmer_id = ask("Farmer ID: ").strip()
    litres = read_number("Litres (0.1 to 1000): ", 0.1, 1000)
    fat = read_number("Fat %  (2.0 to 7.0): ", MIN_FAT, MAX_FAT)
    snf = read_number("SNF %  (7.0 to 10.0): ", MIN_SNF, MAX_SNF)
    rate = rate_per_litre(fat, snf)
    rows.append((farmer_id, litres, fat, snf, rate, round(litres * rate, 2)))

print()
print(f"{'ID':<8}{'Litres':>8}{'Fat':>6}{'SNF':>6}{'Rate':>8}{'Amount':>10}")
for farmer_id, litres, fat, snf, rate, amount in rows:
    print(f"{farmer_id:<8}{litres:>8.1f}{fat:>6.1f}{snf:>6.1f}{rate:>8.2f}{amount:>10.2f}")
total = sum(row[5] for row in rows)
print(f"{'Total':<28}{'':>8}{total:>10.2f}")
print("\nformat examples: {33400.3:10.2f} ->", f"[{33400.3:10.2f}]", "| {33400.3:,.2f} ->", f"[{33400.3:,.2f}]")
