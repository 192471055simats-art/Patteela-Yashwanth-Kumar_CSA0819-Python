"""Task 2: alternative solutions - integer paise and float with round() after each addition."""
import sys, time
from decimal import Decimal

payments = ["33.40"] * 1000 + ["0.10"] * 3

def total_paise(items):
    total = 0
    for amount in items:
        total += round(Decimal(amount) * 100)       # "33.40" -> 3340
    return total

def total_rounded(items):
    total = 0.0
    for amount in items:
        total = round(total + float(amount), 2)
    return total

def total_decimal(items):
    total = Decimal("0")
    for amount in items:
        total += Decimal(amount)
    return total

paise = total_paise(payments)
print("integer paise :", paise, "->", paise // 100, "Rs", paise % 100, "paise")
print("float + round :", total_rounded(payments))
print("Decimal       :", total_decimal(payments))

print("\nMemory per value (sys.getsizeof, bytes)")
print("int     3340          :", sys.getsizeof(3340))
print("float   33.40         :", sys.getsizeof(33.40))
print("Decimal 33.40         :", sys.getsizeof(Decimal("33.40")))

print("\nTime per addition, n = 150000 payments (pre-converted values)")
n = 150000
ints = [3340] * n
floats = [33.40] * n
decs = [Decimal("33.40")] * n

t = time.perf_counter(); s = 0
for v in ints: s += v
t_int = time.perf_counter() - t
t = time.perf_counter(); s = 0.0
for v in floats: s = round(s + v, 2)
t_round = time.perf_counter() - t
t = time.perf_counter(); s = Decimal("0")
for v in decs: s += v
t_dec = time.perf_counter() - t
print(f"int addition            : {t_int/n*1e9:7.1f} ns per addition")
print(f"float + round() each    : {t_round/n*1e9:7.1f} ns per addition")
print(f"Decimal addition        : {t_dec/n*1e9:7.1f} ns per addition")

print("\nExact bank total for n payments of Rs 33.40 (true total = n x 33.40)")
for n in (300, 6000, 150000):
    exact = Decimal("33.40") * n
    p_int = sum([3340] * n)
    f_round = 0.0
    for _ in range(n):
        f_round = round(f_round + 33.40, 2)
    print(f"n={n:>7}: true={exact}  int paise={p_int/100:.2f}  float+round={f_round!r}  "
          f"float+round equals true: {Decimal(str(f_round)) == exact}")
