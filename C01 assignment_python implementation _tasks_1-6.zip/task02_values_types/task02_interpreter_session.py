"""Task 2: reproduce the interactive-interpreter session (each line is really evaluated)."""
session = [
    "type(10)", "type(10.0)", 'type("10")', "type(True)", "type([10, 8.5])",
    "isinstance(True, int)",
    "7 / 2", "7 // 2", "7 % 2", "-7 // 2", "-7 % 2",
    "0.1 + 0.2", "0.1 + 0.2 == 0.3",
]
for expression in session:
    print(">>>", expression)
    print(repr(eval(expression)))
