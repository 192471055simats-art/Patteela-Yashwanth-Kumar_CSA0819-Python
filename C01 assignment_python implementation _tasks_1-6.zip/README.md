# Python Programming Assignment: Milk Payment Problem

Implementation files for the assignment tasks. Every task has its own folder with the
program (`.py`), an input file (`input.txt`) and the output produced by running it
(`output*.txt`).

## Folder structure (Tasks 1 to 6)

| Folder | Task | Programs | Input | Output |
|---|---|---|---|---|
| `task01_problem_analysis` | 1 Understand the problem | `task01_analysis.py` | `input.txt` (none needed) | `output.txt` |
| `task02_values_types` | 2 Values and types | `task02_interpreter_session.py`, `task02_decimal_total.py`, `task02_alternatives.py` | `input.txt` (none needed) | `output_session.txt`, `output_decimal_total.txt`, `output_alternatives.txt` |
| `task03_constants` | 3 Variables and constants | `task03_constants.py` | `input.txt` (none needed) | `output.txt` |
| `task04_expressions` | 4 Expressions | `task04_expressions.py` | `input.txt` (none needed) | `output.txt` |
| `task05_input_conversion` | 5 Input and type conversion | `task05_input.py`, `task05_alt_try_except.py` | `input.txt` | `output.txt`, `output_alt.txt` |
| `task06_functions` | 6 Functions | `milkfunctions.py`, `task06_demo.py`, `task06_alternatives.py` | `input.txt` (none needed) | `output_demo.txt`, `output_alternatives.txt` |

Tasks 7 to 12 will be added in the same way.

## How to run

Python 3.8 or later is needed (the outputs were produced with Python 3.12). Run each
program from inside its own folder:

```
cd task01_problem_analysis
python task01_analysis.py

cd ../task05_input_conversion
python task05_input.py < input.txt        # reads the answers from input.txt
python task05_alt_try_except.py

cd ../task06_functions
python task06_demo.py
```

## Notes

- Timings in the output files depend on the computer and change slightly between runs.
- Assumed rate card (not given in the question): base Rs 30.00 at 3.5 % fat and 8.5 % SNF,
  Rs 0.40 per 0.1 % of fat and Rs 0.30 per 0.1 % of SNF above or below the standard.
- Output screenshots: run each program on your own computer and save a screenshot
  into the task folder (for example `screenshot_task01.png`).
