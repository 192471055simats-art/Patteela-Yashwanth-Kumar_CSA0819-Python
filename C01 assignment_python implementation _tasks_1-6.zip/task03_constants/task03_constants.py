"""Task 3: constants, naming, dynamic typing, multiple assignment and alternatives."""
import sys, timeit

# ---------- the rate card and limits as named constants ----------
BASE_RATE     = 30.0   # Rs per litre at standard quality
FAT_RATE      = 0.40   # Rs per litre for each fat step
SNF_RATE      = 0.30   # Rs per litre for each SNF step
STANDARD_FAT  = 3.5
STANDARD_SNF  = 8.5
STEP          = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 7.0, 10.0
DAYS = 10
SHIFTS = ("M", "E")
MAX_FARMERS = 300

print("1. Constants")
for name in ("BASE_RATE", "FAT_RATE", "SNF_RATE", "STANDARD_FAT", "STANDARD_SNF", "STEP"):
    print(f"   {name:<13}= {globals()[name]}")

print("\n2. Naming rules")
for candidate in ("fat_steps", "ten_day_total", "2fat", "fat steps", "for", "Fat"):
    ok = candidate.isidentifier() and candidate not in ("for", "if", "class")
    print(f"   {candidate!r:<16} valid name: {ok}")
print("   fat and Fat are different variables:", "fat" != "Fat")

print("\n3. Python has no true constants")
print("   BASE_RATE before:", BASE_RATE)
BASE_RATE = 35.0
print("   BASE_RATE after BASE_RATE = 35.0 (no error):", BASE_RATE)
BASE_RATE = 30.0                      # restore the real value

print("\n4. Dynamic typing")
x = 10
print("   x = 10     ->", type(x))
x = "ten"
print('   x = "ten"  ->', type(x))
try:
    x + 1
except TypeError as error:
    print("   x + 1 raises TypeError:", error)
litres = "12.5"                       # what input() would return
print("   input() style text:", repr(litres), type(litres))
print("   after float(litres):", float(litres), type(float(litres)))

print("\n5. Multiple assignment and swapping")
farmer_id, litres, fat = "F001", 12.5, 4.2
print("  ", farmer_id, litres, fat)
litres_m, litres_e = 10.0, 14.0
print("   before swap:", litres_m, litres_e)
litres_m, litres_e = litres_e, litres_m
print("   after swap :", litres_m, litres_e)

# ---------- alternatives: magic numbers, dictionary, named constants ----------
RATE_CARD = {"base": 30.0, "fat": 0.40, "snf": 0.30}
fat_steps, snf_steps = 7, 2

def rate_magic():
    return 30.0 + fat_steps * 0.40 + snf_steps * 0.30

def rate_dict():
    return RATE_CARD["base"] + fat_steps * RATE_CARD["fat"] + snf_steps * RATE_CARD["snf"]

def rate_constants():
    return BASE_RATE + fat_steps * FAT_RATE + snf_steps * SNF_RATE

print("\n6. Alternatives (same rate from three designs)")
print("   magic numbers  :", rate_magic())
print("   dictionary     :", rate_dict())
print("   named constants:", rate_constants())

n = 1_000_000
print(f"\n   time per call ({n} calls):")
for label, func in (("magic numbers", rate_magic), ("dictionary", rate_dict), ("named constants", rate_constants)):
    t = timeit.timeit(func, number=n) / n
    print(f"   {label:<16}{t*1e9:7.1f} ns")

print("\n   memory: dictionary object =", sys.getsizeof(RATE_CARD), "bytes;",
      "three floats =", 3 * sys.getsizeof(0.40), "bytes")

# places to change when the fat step value 0.40 is revised
program_with_magic = "\n".join(["rate = 30.0 + fat_steps * 0.40 + snf_steps * 0.30"] * 5)  # k = 5 uses
print("\n   places to edit for a rate revision, k = 5 uses of the fat step in the program:")
print("   magic numbers   :", program_with_magic.count("0.40"), "places")
print("   dictionary      : 1 place")
print("   named constants : 1 place")
