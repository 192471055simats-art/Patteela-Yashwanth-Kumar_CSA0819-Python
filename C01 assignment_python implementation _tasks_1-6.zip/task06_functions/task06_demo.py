"""Task 6: demonstration of the functions, return versus print, scope and docstrings."""
import milkfunctions as mf

entries = [(10.0, 4.2, 8.5), (12.0, 3.8, 8.4), (8.5, 4.0, 8.6)]

print("1. Functions with parameters and return values")
print(f"Rate for fat 4.2, SNF 8.5: Rs {mf.rate_per_litre(4.2, 8.5):.2f} per litre")
print(f"Payout for 10.0 L: Rs {mf.payout(10.0, 4.2, 8.5):.2f}")
print(f"Ten-day total: Rs {mf.ten_day_total(entries):.2f}")
print("is_valid_entry(10, 4.2, 8.5, 'M') ->", mf.is_valid_entry(10, 4.2, 8.5, "M"))
print("is_valid_entry(10, 9.0, 8.5, 'M') ->", mf.is_valid_entry(10, 9.0, 8.5, "M"))

print("\n2. Aligned lines from show_entry (it prints and returns None)")
print(f"{'ID':<8}{'Litres':>8}{'Fat':>6}{'SNF':>6}{'Rate':>8}{'Amount':>10}")
for number, (litres, fat, snf) in enumerate(entries, start=1):
    mf.show_entry(f"F00{number}", litres, fat, snf)
print("value returned by show_entry:", mf.show_entry("F009", 1.0, 3.5, 8.5))

print("\n3. Returning a value versus printing it")
def bad_payout(litres, fat, snf):
    print("   (printed inside) ", litres * mf.rate_per_litre(fat, snf))   # prints, returns None

result = bad_payout(10.0, 4.2, 8.5)
print("   value returned by bad_payout:", result)
try:
    total = 0.0
    total += result
except TypeError as error:
    print("   total += result fails:", error)

print("\n4. Local and global names")
def local_rate():
    BASE_RATE = 99.0                 # a NEW local variable
    return BASE_RATE
print("   local_rate() returns", local_rate(), "but the global BASE_RATE is still", mf.BASE_RATE)

def worse_rate():
    mf_base = mf.BASE_RATE           # reading a global is fine
    BASE_RATE += 1                   # assigning to a name makes it local -> error
    return BASE_RATE
try:
    worse_rate()
except UnboundLocalError as error:
    print("   BASE_RATE += 1 inside a function raises UnboundLocalError:", error)

print("\n5. Docstrings")
print(mf.payout.__doc__)
print("first line of every docstring:")
for func in (mf.rate_per_litre, mf.payout, mf.is_valid_entry, mf.ten_day_total, mf.show_entry):
    print(f"   {func.__name__:<16}{func.__doc__.splitlines()[0]}")
