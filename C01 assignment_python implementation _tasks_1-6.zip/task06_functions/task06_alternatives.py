"""Task 6 alternatives: one long script, and lambda expressions; compare repeated code and time."""
import time
import milkfunctions as mf

BASE_RATE, FAT_RATE, SNF_RATE = 30.0, 0.40, 0.30
STANDARD_FAT, STANDARD_SNF, STEP = 3.5, 8.5, 0.1

# lambda version
rate_lambda = lambda fat, snf: (BASE_RATE
    + round((fat - STANDARD_FAT) / STEP) * FAT_RATE
    + round((snf - STANDARD_SNF) / STEP) * SNF_RATE)
payout_lambda = lambda litres, fat, snf: litres * rate_lambda(fat, snf)

def make_entries(n):
    return [(10.0 + i % 10, 3.0 + (i % 30) / 10, 8.0 + (i % 15) / 10) for i in range(n)]

def total_script(entries):
    """No functions: the calculation is written inline."""
    total = 0.0
    for litres, fat, snf in entries:
        fat_steps = round((fat - STANDARD_FAT) / STEP)
        snf_steps = round((snf - STANDARD_SNF) / STEP)
        rate = BASE_RATE + fat_steps * FAT_RATE + snf_steps * SNF_RATE
        total += litres * rate
    return total

def total_lambda(entries):
    total = 0.0
    for litres, fat, snf in entries:
        total += payout_lambda(litres, fat, snf)
    return total

print("1. All three designs give the same total")
data = make_entries(6000)
print("   functions:", round(mf.ten_day_total(data), 2))
print("   script   :", round(total_script(data), 2))
print("   lambda   :", round(total_lambda(data), 2))

print("\n2. Repeated code: number of times the 4-line calculation must be written")
print("   functions: 1 definition, used anywhere by name")
print("   script   : 1 copy for every place a payout is needed (m copies)")
print("   lambda   : 1 expression, but no docstring and no statements allowed")
print("   traceback name of a lambda:", payout_lambda.__name__)

print("\n3. Time for n entries (function-call overhead)")
print(f"   {'n':>8}{'functions':>14}{'script':>14}{'lambda':>14}")
for n in (6000, 150000):
    data = make_entries(n)
    row = []
    for func in (mf.ten_day_total, total_script, total_lambda):
        times = []
        for _ in range(5):
            t0 = time.perf_counter()
            func(data)
            times.append(time.perf_counter() - t0)
        row.append(min(times))
    print(f"   {n:>8}" + "".join(f"{t*1000:>11.2f} ms" for t in row))
