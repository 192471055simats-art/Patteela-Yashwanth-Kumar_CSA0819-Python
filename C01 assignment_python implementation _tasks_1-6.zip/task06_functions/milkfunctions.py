"""Task 6: the payment calculation divided into functions (module)."""

BASE_RATE = 30.0
FAT_RATE = 0.40
SNF_RATE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 7.0, 10.0
SHIFTS = ("M", "E")


def rate_per_litre(fat, snf):
    """Return the rate in Rs per litre for the given fat % and SNF %.

    Parameters: fat (float), snf (float).
    Returns: float. Reads the rate-card constants but never changes them.
    """
    fat_steps = round((fat - STANDARD_FAT) / STEP)
    snf_steps = round((snf - STANDARD_SNF) / STEP)
    return BASE_RATE + fat_steps * FAT_RATE + snf_steps * SNF_RATE


def payout(litres, fat, snf):
    """Return the amount in Rs payable for one delivery.

    Parameters: litres (float), fat (float), snf (float).
    Returns: float, litres multiplied by the rate per litre.
    """
    return litres * rate_per_litre(fat, snf)


def is_valid_entry(litres, fat, snf, shift):
    """Return True if every value obeys the payment rules, else False."""
    return (litres > 0
            and MIN_FAT <= fat <= MAX_FAT
            and MIN_SNF <= snf <= MAX_SNF
            and shift in SHIFTS)


def ten_day_total(entries):
    """Return the total payout in Rs for a list of entries.

    Parameters: entries, a list of (litres, fat, snf) tuples.
    Returns: float, the sum of the payout of each entry.
    """
    total = 0.0
    for litres, fat, snf in entries:
        total += payout(litres, fat, snf)
    return total


def show_entry(farmer_id, litres, fat, snf):
    """Print one aligned line for a delivery. Returns None."""
    print(f"{farmer_id:<8}{litres:>8.1f}{fat:>6.1f}{snf:>6.1f}"
          f"{rate_per_litre(fat, snf):>8.2f}{payout(litres, fat, snf):>10.2f}")
