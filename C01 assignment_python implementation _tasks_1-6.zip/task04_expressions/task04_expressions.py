"""Task 4: expressions for steps, rate and amount; precedence; round/int/floor; chaining."""
import math, timeit

BASE_RATE, FAT_RATE, SNF_RATE = 30.0, 0.40, 0.30
STANDARD_FAT, STANDARD_SNF, STEP = 3.5, 8.5, 0.1

print("1. The expressions (fat 4.2, SNF 8.5, litres 10)")
fat, snf, litres = 4.2, 8.5, 10
fat_steps = round((fat - STANDARD_FAT) / STEP)
snf_steps = round((snf - STANDARD_SNF) / STEP)
rate = BASE_RATE + fat_steps * FAT_RATE + snf_steps * SNF_RATE
amount = litres * rate
valid_fat = 2.0 <= fat <= 7.0
print("   fat_steps =", fat_steps, " snf_steps =", snf_steps)
print(f"   rate = {rate:.2f}  amount = {amount:.2f}  valid_fat = {valid_fat}")

print("\n2. Interactive-style session: unexpected results")
session = [
    "(4.2 - 3.5) / 0.1", "round((4.2 - 3.5) / 0.1)",
    "-2 ** 2", "(-2) ** 2", "2 ** 3 ** 2", "2 ** -1",
    "round(2.5), round(3.5), round(0.5)",
    "int(-3.7), math.floor(-3.7), round(-3.7)",
    "0.1 * 3", "True and False or True",
    "2.0 <= 9.5 <= 7.0", "2.0 <= 4.2 <= 7.0",
]
for expression in session:
    print(">>>", expression)
    print(repr(eval(expression)))

print("\n3. Chained comparison equals the long form")
for fat_value in (1.9, 2.0, 4.2, 7.0, 7.1):
    print(f"   fat = {fat_value}: chained {2.0 <= fat_value <= 7.0}   "
          f"long form {(2.0 <= fat_value) and (fat_value <= 7.0)}")

print("\n4. Alternative: int() or math.floor() instead of round() for the step count")
print(f"   {'fat':<5}{'(fat-3.5)/0.1':<24}{'method':<7}{'steps':>6}{'rate':>8}")
for fat_value in (4.2, 3.1, 4.1):
    exact = (fat_value - STANDARD_FAT) / STEP
    for name, steps in (("round", round(exact)), ("int", int(exact)), ("floor", math.floor(exact))):
        print(f"   {fat_value:<5}{exact!r:<24}{name:<7}{steps:>6}{BASE_RATE + steps * FAT_RATE:>8.2f}")

print("\n5. Time cost of each (O(1)), 1,000,000 calls each")
for label, stmt in (("round", "round(x)"), ("int", "int(x)"), ("floor", "math.floor(x)")):
    t = timeit.timeit(stmt, globals={"x": 6.999999999999999, "math": math}, number=1_000_000) / 1_000_000
    print(f"   {label:<6}{t*1e9:7.1f} ns")
