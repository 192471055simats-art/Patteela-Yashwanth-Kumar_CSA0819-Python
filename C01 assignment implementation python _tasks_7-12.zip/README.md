# Python Programming Assignment: Milk Payment Problem (Tasks 7 to 12)

Every task has its own folder with the programs (`.py`), an input file (`input.txt`)
and the output produced by running them (`output*.txt`). Run each program from inside
its own folder.

| Folder | Task | Programs | Input | Output |
|---|---|---|---|---|
| `task07_module` | 7 Build a module | `milkrate.py`, `report.py`, `task07_alternatives.py` | `input.txt` (none needed) | `output_milkrate.txt`, `output_report.txt`, `output_alternatives.txt` |
| `task08_algorithm` | 8 Plan the algorithm | `task08_payment.py`, `milkrate.py`, `task08_alternatives.py` | `input.txt`, `input_with_invalid.txt` | `output.txt`, `output_with_invalid.txt`, `output_alternatives.txt` |
| | | `pseudocode.txt`, `hand_trace.txt`, `flowchart_validate_entry.png` (and `.dot` source) | | |
| `task09_testing` | 9 Implement and test | `calculator.py`, `test_calculator.py`, `task09_alternatives.py` | `input.txt` (none needed) | `output.txt`, `output_alternatives.txt` |
| `task10_comparison` | 10 Expectation vs execution | `task10_float_vs_decimal.py`, `task10_rounding_policy.py`, `task10_rate_table.py`, `calculator.py` | `input.txt` (none needed) | `output_float_vs_decimal.txt`, `output_rounding_policy.txt`, `output_rate_table.txt` |
| `task11_final_design` | 11 Final design | `milkrate_final.py`, `test_final.py`, `task11_tie_readings.py`, `task11_scale.py`, `task11_json_ratecard.py`, `ratecard.json` | `input.txt` (none needed) | `output_test_final.txt`, `output_tie_readings.txt`, `output_scale.txt`, `output_json_ratecard.txt` |
| `task12_redesign` | 12 Day-4 design challenge | `milkrate_v2.py`, `test_v2.py`, `report.py`, `task12_original_vs_new.py`, `milkrate_final.py`, `milkrate_float.py`, `uml_diagram.png` (and `.dot` source) | `input.txt` (none needed) | `output_test_v2.txt`, `output_report.txt`, `output_original_vs_new.txt` |

## How to run

Python 3.8 or later is needed (the outputs were produced with Python 3.12).

```
cd task07_module     && python report.py
cd task08_algorithm  && python task08_payment.py < input.txt
cd task09_testing    && python test_calculator.py
cd task10_comparison && python task10_float_vs_decimal.py
cd task11_final_design && python test_final.py
cd task12_redesign   && python test_v2.py && python report.py
```

## Notes

- Timings in the output files depend on the computer and change slightly between runs.
- Task 12 assumptions: the SNF step stays Rs 0.30 in April to June; the Rs 0.50 bonus is paid
  on all litres when the ten-day total is more than 500 litres; readings have at most two decimals.
- Output screenshots: run each program on your own computer and save a screenshot into the
  task folder (for example `screenshot_task07.png`).
