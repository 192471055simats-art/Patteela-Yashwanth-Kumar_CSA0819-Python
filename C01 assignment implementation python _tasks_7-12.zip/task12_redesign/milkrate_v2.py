"""Revised design (Task 12): seasonal rate cards, two-decimal readings, ten-day bonus."""
from decimal import Decimal, ROUND_HALF_UP

# ---------- rate cards: one entry per season ----------
RATE_CARDS = {
    "APR-JUN":  {"base": Decimal("32.00"), "fat_step": Decimal("0.45"), "snf_step": Decimal("0.30")},
    "STANDARD": {"base": Decimal("30.00"), "fat_step": Decimal("0.40"), "snf_step": Decimal("0.30")},
}
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP = Decimal("0.1")
BONUS_THRESHOLD_LITRES = Decimal("500")
BONUS_PER_LITRE = Decimal("0.50")
PAISE = Decimal("0.01")
WHOLE = Decimal("1")
MIN_FAT, MAX_FAT = Decimal("2.00"), Decimal("7.00")
MIN_SNF, MAX_SNF = Decimal("7.00"), Decimal("10.00")


def season_for_month(month):
    """Return the rate-card name for a month number (1 to 12)."""
    return "APR-JUN" if 4 <= month <= 6 else "STANDARD"


def to_decimal(text):
    """Convert typed text such as '4.25' to Decimal; raise ValueError if not a number."""
    text = str(text).strip()
    if not text.replace(".", "", 1).isdigit():
        raise ValueError("not a valid number: " + repr(text))
    return Decimal(text)


def is_valid_entry(litres, fat, snf):
    """Return True if litres > 0 and fat and SNF are inside the allowed ranges."""
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF


def count_steps(reading, standard):
    """Return the whole number of 0.1 steps from the standard (ties round away from zero)."""
    return ((reading - standard) / STEP).quantize(WHOLE, rounding=ROUND_HALF_UP)


def rate_per_litre(fat, snf, season):
    """Return the Rs per litre for the season's rate card, rounded to paise."""
    card = RATE_CARDS[season]
    rate = (card["base"] + count_steps(fat, STANDARD_FAT) * card["fat_step"]
            + count_steps(snf, STANDARD_SNF) * card["snf_step"])
    return rate.quantize(PAISE, rounding=ROUND_HALF_UP)


def payout(litres, fat, snf, season):
    """Return the amount in Rs for one delivery, rounded to paise."""
    return (litres * rate_per_litre(fat, snf, season)).quantize(PAISE, rounding=ROUND_HALF_UP)


def bonus(total_litres):
    """Return the bonus in Rs: Rs 0.50 per litre if total litres exceed 500, else 0.00."""
    if total_litres > BONUS_THRESHOLD_LITRES:
        return (total_litres * BONUS_PER_LITRE).quantize(PAISE, rounding=ROUND_HALF_UP)
    return Decimal("0.00")


def ten_day_total(entries, season):
    """Return (litres, payments, bonus, grand_total) for the valid typed entries."""
    litres_sum = Decimal("0")
    payments = Decimal("0.00")
    for litres, fat, snf in entries:
        try:
            l, f, s = to_decimal(litres), to_decimal(fat), to_decimal(snf)
        except ValueError:
            continue
        if is_valid_entry(l, f, s):
            litres_sum += l
            payments += payout(l, f, s, season)
    extra = bonus(litres_sum)
    return litres_sum, payments, extra, payments + extra
