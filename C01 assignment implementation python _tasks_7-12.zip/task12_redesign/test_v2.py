from decimal import Decimal as D
from milkrate_v2 import *

print(f"{'Case':<44}{'Expected':>10}{'Actual':>10}  Result")
def check(name, actual, expected):
    ok = actual == D(expected)
    print(f"{name:<44}{expected:>10}{str(actual):>10}  {'PASS' if ok else 'FAIL'}")
    assert ok, name

# rates and payouts for one delivery: litres, fat, snf
check("STANDARD rate, 4.20 / 8.70",            rate_per_litre(D("4.20"), D("8.70"), "STANDARD"), "33.40")
check("APR-JUN rate, 4.20 / 8.70",             rate_per_litre(D("4.20"), D("8.70"), "APR-JUN"),  "35.75")
check("STANDARD rate, 4.25 / 8.65 (ties)",     rate_per_litre(D("4.25"), D("8.65"), "STANDARD"), "33.80")
check("APR-JUN rate, 4.25 / 8.65 (ties)",      rate_per_litre(D("4.25"), D("8.65"), "APR-JUN"),  "36.20")
check("STANDARD rate, 3.45 / 8.45 (neg. tie)", rate_per_litre(D("3.45"), D("8.45"), "STANDARD"), "29.30")
check("APR-JUN payout, 10 L, 4.20 / 8.70",     payout(D("10"), D("4.20"), D("8.70"), "APR-JUN"), "357.50")
check("STANDARD payout, 10 L, 4.20 / 8.70",    payout(D("10"), D("4.20"), D("8.70"), "STANDARD"), "334.00")
check("Season of month 5 (May) is APR-JUN",    D("1") if season_for_month(5)=="APR-JUN" else D("0"), "1")
check("Season of month 7 (July) is STANDARD",  D("1") if season_for_month(7)=="STANDARD" else D("0"), "1")
# bonus
check("Bonus, 450 L (below 500)",              bonus(D("450")),    "0.00")
check("Bonus, exactly 500 L (not more than)",  bonus(D("500")),    "0.00")
check("Bonus, 500.01 L",                       bonus(D("500.01")), "250.01")
check("Bonus, 600 L",                          bonus(D("600")),    "300.00")
# ten-day totals: 10 deliveries of 55 L at 4.20 / 8.70
ten = [("55", "4.20", "8.70")] * 10
l, p, b, g = ten_day_total(ten, "APR-JUN")
check("May, 550 L: payments",  p, "19662.50"); check("May, 550 L: bonus", b, "275.00"); check("May, 550 L: grand total", g, "19937.50")
l, p, b, g = ten_day_total(ten, "STANDARD")
check("Nov, 550 L: payments",  p, "18370.00"); check("Nov, 550 L: bonus", b, "275.00"); check("Nov, 550 L: grand total", g, "18645.00")
l, p, b, g = ten_day_total([("50", "4.20", "8.70")] * 10, "APR-JUN")
check("May, exactly 500 L: bonus", b, "0.00")
# invalid input still rejected
l, p, b, g = ten_day_total(ten + [("abc","4.2","8.7"), ("10","7.5","8.7"), ("-1","4.2","8.7")], "APR-JUN")
check("Invalid entries skipped: grand total", g, "19937.50")
print("\nall revised-design tests pass")
