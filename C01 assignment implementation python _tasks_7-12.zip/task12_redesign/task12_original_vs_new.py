"""Task 12 part B: the Task 7 float design and the Task 11 Decimal design on two-decimal readings."""
import milkrate_float as old
import milkrate_final as new
from decimal import Decimal as D

print(f"{'fat / snf':<14}{'float design':>14}{'Decimal design':>16}{'difference':>12}   effect on 10 L")
for fat, snf in [("4.05", "8.50"), ("4.35", "8.50"), ("3.45", "8.45"), ("4.15", "8.65"), ("4.25", "8.65")]:
    old_rate = D(str(old.rate_per_litre(float(fat), float(snf))))
    new_rate = new.rate_per_litre(D(fat), D(snf))
    diff = old_rate - new_rate
    effect = "same" if diff == 0 else ("farmer underpaid by %s" % (-diff * 10) if diff < 0 else "farmer overpaid by %s" % (diff * 10))
    print(f"{fat + ' / ' + snf:<14}{old_rate:>14.2f}{new_rate:>16}{diff:>12.2f}   {effect}")
