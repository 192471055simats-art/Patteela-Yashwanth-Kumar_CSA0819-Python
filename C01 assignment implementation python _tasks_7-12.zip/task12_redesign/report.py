import milkrate_v2 as mr

entries = [("55", "4.20", "8.70")] * 10          # ten deliveries of 55 L
for month in (5, 11):                             # May and November
    season = mr.season_for_month(month)
    litres, payments, extra, grand = mr.ten_day_total(entries, season)
    print(f"Month {month:>2} ({season:<8}) litres {litres:>4}  payments {payments:>9}  "
          f"bonus {extra:>7}  total {grand:>9}")
