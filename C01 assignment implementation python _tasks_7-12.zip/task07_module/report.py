import milkrate
from milkrate import payout
import milkrate as mr

print("Payout:", payout(10, 3.5, 8.5))
print("Rate:", mr.rate_per_litre(4.2, 8.7))
print("Base rate:", milkrate.BASE_RATE)
print("Module name:", milkrate.__name__)
