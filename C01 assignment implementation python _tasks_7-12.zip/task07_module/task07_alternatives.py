"""Task 7 alternatives: how Python finds and loads a module, and the cost of importing it."""
import sys, time, importlib

print("1. Where Python looks for a module (sys.path, in order)")
for number, folder in enumerate(sys.path, start=1):
    print(f"   {number}. {folder or '(current folder)'}")

print("\n2. Is milkrate loaded yet?  ", "milkrate" in sys.modules)
t = time.perf_counter()
import milkrate                                   # first import: find, compile, run the file once
first = time.perf_counter() - t
print("   after the first import:   ", "milkrate" in sys.modules)

t = time.perf_counter()
import milkrate                                   # later imports: only a lookup in sys.modules
second = time.perf_counter() - t
print(f"\n3. Import cost: first import {first*1e6:.1f} microseconds, second import {second*1e6:.2f} microseconds")

n = 100000
t = time.perf_counter()
for _ in range(n):
    importlib.import_module("milkrate")
print(f"   repeated import (average of {n}): {(time.perf_counter() - t) / n * 1e9:.0f} ns each")

print("\n4. __name__ in each situation")
print("   milkrate.__name__ when imported:", milkrate.__name__)
print("   __name__ of this script        :", __name__)

print("\n5. Copying the functions into k scripts instead of importing")
for k in (1, 5, 20):
    print(f"   k = {k:>2} scripts: copy -> {k} files to edit for a rate change; import -> 1 file")
