"""Task 9 alternative: time to rerun all tests automatically (assert) versus typing by hand."""
import time
from calculator import calculate_entry, ten_day_total

CASES = [("10", "4.2", "8.7", 334.0), ("10", "3.1", "8.3", 278.0), ("10", "3.5", "8.5", 300.0),
         ("10", "2.0", "8.5", 240.0), ("10", "7.0", "8.5", 440.0), ("abc", "4.0", "8.5", None),
         ("-5", "4.0", "8.5", None), ("10", "7.5", "8.5", None), ("10", "1.9", "8.5", None)]
FIVE = [("10", "3.5", "8.5"), ("8.5", "4.2", "8.7"), ("12", "3.1", "8.3"), ("20", "5.0", "9.0"), ("15", "2.0", "8.0")]

def run_all():
    for litres, fat, snf, expected in CASES:
        assert calculate_entry(litres, fat, snf) == expected
    assert ten_day_total(FIVE) == 2005.0

runs = 2000
t = time.perf_counter()
for _ in range(runs):
    run_all()
per_run = (time.perf_counter() - t) / runs
print(f"Automated: one full run of all 10 checks = {per_run*1e6:.1f} microseconds")

checks = 14                      # 9 single cases + 5 entries of the hand-checked set
seconds_per_check = 20           # assumption: time to type 3 values and compare by eye
print(f"Manual (assumed {seconds_per_check} s per check): {checks} checks = {checks*seconds_per_check/60:.1f} minutes per rerun")
for changes in (1, 5, 20):
    manual = changes * checks * seconds_per_check
    print(f"  after {changes:>2} code changes: manual {manual/60:6.1f} minutes, automated {changes*per_run*1e3:.4f} milliseconds")
