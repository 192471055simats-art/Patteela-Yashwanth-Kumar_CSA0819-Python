"""Milk payment calculator for the village co-operative."""

BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 7.0, 10.0


def to_number(text):
    """Convert text such as '8.5' to float; raise ValueError if it is not a number."""
    text = str(text).strip()
    if not text.replace(".", "", 1).isdigit():
        raise ValueError("not a valid number: " + repr(text))
    return float(text)


def is_valid_entry(litres, fat, snf):
    """Return True if litres > 0 and fat and SNF are inside the allowed ranges."""
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF


def rate_per_litre(fat, snf):
    """Return the rate in Rs per litre, rounded to 2 decimals."""
    fat_steps = round((fat - STANDARD_FAT) / STEP)
    snf_steps = round((snf - STANDARD_SNF) / STEP)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)


def payout(litres, fat, snf):
    """Return the amount in Rs for one delivery, rounded to 2 decimals."""
    return round(litres * rate_per_litre(fat, snf), 2)


def calculate_entry(litres_text, fat_text, snf_text):
    """Return the payout for one typed entry, or None if the entry is invalid."""
    try:
        litres, fat, snf = to_number(litres_text), to_number(fat_text), to_number(snf_text)
    except ValueError:
        return None
    if not is_valid_entry(litres, fat, snf):
        return None
    return payout(litres, fat, snf)


def ten_day_total(entries):
    """Return the total payout for a list of (litres, fat, snf) typed entries."""
    total = 0.0
    for litres, fat, snf in entries:
        amount = calculate_entry(litres, fat, snf)
        if amount is not None:
            total += amount
    return round(total, 2)
