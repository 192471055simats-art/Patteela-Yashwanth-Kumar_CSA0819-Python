from calculator import calculate_entry, ten_day_total

# (description, litres, fat, snf, expected)
CASES = [
    ("Normal: fat and SNF above standard", "10", "4.2", "8.7", 334.00),
    ("Normal: fat and SNF below standard", "10", "3.1", "8.3", 278.00),
    ("Boundary: exactly 3.5 fat, 8.5 SNF", "10", "3.5", "8.5", 300.00),
    ("Boundary: lowest allowed fat 2.0",    "10", "2.0", "8.5", 240.00),
    ("Boundary: highest allowed fat 7.0",   "10", "7.0", "8.5", 440.00),
    ("Invalid: litres is text",             "abc", "4.0", "8.5", None),
    ("Invalid: negative litres",            "-5", "4.0", "8.5", None),
    ("Invalid: fat above 7.0",              "10", "7.5", "8.5", None),
    ("Invalid: fat below 2.0",              "10", "1.9", "8.5", None),
]

passed = 0
print(f"{'Case':<38}{'Expected':>10}{'Actual':>10}  Result")
for name, l, f, s, expected in CASES:
    actual = calculate_entry(l, f, s)
    ok = actual == expected
    passed += ok
    print(f"{name:<38}{str(expected):>10}{str(actual):>10}  {'PASS' if ok else 'FAIL'}")
    assert actual == expected, name

FIVE = [("10", "3.5", "8.5"), ("8.5", "4.2", "8.7"), ("12", "3.1", "8.3"),
        ("20", "5.0", "9.0"), ("15", "2.0", "8.0")]
total = ten_day_total(FIVE)
print("\nFive-entry total: expected 2005.0, actual", total)
assert total == 2005.00
# a bad entry in the list must be skipped, not crash and not be added
assert ten_day_total(FIVE + [("abc", "4.0", "8.5")]) == 2005.00
print(f"\n{passed} single-entry tests and 3 total tests passed")
