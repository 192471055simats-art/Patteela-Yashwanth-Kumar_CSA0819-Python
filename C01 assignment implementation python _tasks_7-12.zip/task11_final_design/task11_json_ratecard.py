"""Task 11 alternative: read the rate card from a JSON file at start-up; time and space for t values."""
import json, os, sys, time
from decimal import Decimal

with open("ratecard.json") as fh:                # the real card, t = 3 values
    card = json.load(fh)
BASE_RATE = Decimal(card["base_rate"])
FAT_STEP_VALUE = Decimal(card["fat_step"])
SNF_STEP_VALUE = Decimal(card["snf_step"])
print("Loaded from ratecard.json:", BASE_RATE, FAT_STEP_VALUE, SNF_STEP_VALUE)

print("\nCost of reading t values")
for t_values in (6, 1000, 100000):
    big = {f"k{i}": str(Decimal(i) / Decimal(100)) for i in range(t_values)}
    path = f"card_{t_values}.json"
    with open(path, "w") as fh:
        json.dump(big, fh)
    reps = 200 if t_values <= 1000 else 5
    t0 = time.perf_counter()
    for _ in range(reps):
        with open(path) as fh:
            loaded = json.load(fh)
    read = (time.perf_counter() - t0) / reps
    t0 = time.perf_counter()
    for _ in range(reps):
        converted = {k: Decimal(v) for k, v in loaded.items()}
    convert = (time.perf_counter() - t0) / reps
    print(f"t={t_values:>6}: file {os.path.getsize(path):>8} bytes, read {read*1e3:8.3f} ms, "
          f"convert to Decimal {convert*1e3:8.3f} ms, dictionary {sys.getsizeof(loaded)} bytes")
    os.remove(path)
