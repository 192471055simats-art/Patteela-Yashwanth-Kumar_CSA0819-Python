from decimal import Decimal as D
from milkrate_final import *
CASES=[("10","4.2","8.7","334.00"),("10","3.1","8.3","278.00"),("10","3.5","8.5","300.00"),
("10","2.0","8.5","240.00"),("10","7.0","8.5","440.00")]
for l,f,s,e in CASES:
    assert payout(to_decimal(l),to_decimal(f),to_decimal(s))==D(e),(l,f,s)
FIVE=[("10","3.5","8.5"),("8.5","4.2","8.7"),("12","3.1","8.3"),("20","5.0","9.0"),("15","2.0","8.0")]
print("final design five-entry total:", ten_day_total(FIVE))
assert ten_day_total(FIVE)==D("2005.00")
assert ten_day_total(FIVE+[("abc","4.0","8.5"),("-5","4","8.5"),("10","7.5","8.5")])==D("2005.00")
print("all final-design tests pass")
