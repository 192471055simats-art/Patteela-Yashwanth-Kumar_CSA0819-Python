"""Task 11: does the Decimal design stay correct and fast at district-union scale?"""
import time, random
from milkrate_final import ten_day_total

random.seed(11)

def make(n):
    return [(str(random.randint(50, 300) / 10), f"{random.randint(300, 550) / 100:.2f}",
             f"{random.randint(800, 950) / 100:.2f}") for _ in range(n)]

for n in (6000, 150000, 1000000):
    data = make(n)
    t = time.perf_counter()
    total = ten_day_total(data)
    elapsed = time.perf_counter() - t
    print(f"n={n:>8}: total={total}  time={elapsed:.2f} s  ({elapsed/n*1e6:.1f} us/entry)")
