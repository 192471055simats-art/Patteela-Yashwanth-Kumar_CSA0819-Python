from decimal import Decimal as D, ROUND_HALF_UP
print("fat   float round()  Decimal half-up   exact ratio")
for fat in ["4.05","4.15","4.25","4.35","3.45","3.35","3.65"]:
    f=float(fat); fl=(f-3.5)/0.1
    dec=((D(fat)-D("3.5"))/D("0.1"))
    print(f"{fat}  {fl!r:<22} round->{round(fl):>3}   half-up->{dec.quantize(D('1'),rounding=ROUND_HALF_UP):>3}   exact {dec}")
