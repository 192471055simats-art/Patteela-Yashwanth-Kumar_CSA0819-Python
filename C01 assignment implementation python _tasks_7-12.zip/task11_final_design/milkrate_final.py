"""Final design (Task 11): Decimal types, half-up rounding, one rate card."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP = Decimal("0.1")
PAISE = Decimal("0.01")
WHOLE = Decimal("1")
MIN_FAT, MAX_FAT = Decimal("2.0"), Decimal("7.0")
MIN_SNF, MAX_SNF = Decimal("7.0"), Decimal("10.0")


def to_decimal(text):
    """Convert typed text to Decimal; raise ValueError if it is not a plain number."""
    text = str(text).strip()
    if not text.replace(".", "", 1).isdigit():
        raise ValueError("not a valid number: " + repr(text))
    return Decimal(text)


def is_valid_entry(litres, fat, snf):
    """Return True if litres > 0 and fat and SNF are inside the allowed ranges."""
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF


def count_steps(reading, standard):
    """Return the whole number of 0.1 steps from the standard (ties round away from zero)."""
    return ((reading - standard) / STEP).quantize(WHOLE, rounding=ROUND_HALF_UP)


def rate_per_litre(fat, snf):
    """Return the rate in Rs per litre as a Decimal rounded to paise."""
    rate = (BASE_RATE + count_steps(fat, STANDARD_FAT) * FAT_STEP_VALUE
            + count_steps(snf, STANDARD_SNF) * SNF_STEP_VALUE)
    return rate.quantize(PAISE, rounding=ROUND_HALF_UP)


def payout(litres, fat, snf):
    """Return the amount in Rs for one delivery, rounded to paise."""
    return (litres * rate_per_litre(fat, snf)).quantize(PAISE, rounding=ROUND_HALF_UP)


def ten_day_total(entries):
    """Return the sum of the paise-rounded payouts of the valid (litres, fat, snf) entries."""
    total = Decimal("0.00")
    for litres, fat, snf in entries:
        try:
            l, f, s = to_decimal(litres), to_decimal(fat), to_decimal(snf)
        except ValueError:
            continue
        if is_valid_entry(l, f, s):
            total += payout(l, f, s)
    return total
