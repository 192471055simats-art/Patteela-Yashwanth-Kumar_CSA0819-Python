import random
from decimal import Decimal, ROUND_HALF_UP

random.seed(7)
for n in (300, 6000, 150000):
    each = Decimal(0)
    raw = Decimal(0)
    for _ in range(n):
        litres = Decimal(random.randint(5000, 30000)) / Decimal(1000)   # e.g. 12.345 L
        rate = Decimal(random.randint(2250, 4400)) / Decimal(100)       # e.g. 33.40
        amount = litres * rate
        raw += amount
        each += amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    total_only = raw.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    print(n, each, total_only, each - total_only)
