import time
from decimal import Decimal

pay2 = ["33.40", "0.10", "12.35", "7.07", "0.01"]
for n in (300, 6000, 150000):
    p = [pay2[i % 5] for i in range(n)]

    t = time.perf_counter()
    f = 0.0
    for a in p:
        f += float(a)
    t_float = time.perf_counter() - t

    t = time.perf_counter()
    d = Decimal("0")
    for a in p:
        d += Decimal(a)
    t_dec = time.perf_counter() - t

    print(f"n={n:>7} float={f!r} Decimal={d} diff={Decimal(f) - d:.3e} "
          f"t_float={t_float*1000:.2f} ms t_dec={t_dec*1000:.2f} ms")
