"""Task 10 alternative: rate table (dictionary) versus recalculating the rate for every entry."""
import time, random, sys, timeit
from calculator import rate_per_litre

random.seed(3)
fats = [round(2.0 + 0.1 * i, 1) for i in range(51)]     # 2.0 .. 7.0
snfs = [round(7.0 + 0.1 * i, 1) for i in range(31)]     # 7.0 .. 10.0
n = 150000
print(f"n = {n} entries")
for k in (10, 100, 1000):
    pairs = [(random.choice(fats), random.choice(snfs)) for _ in range(k)]
    pairs = list(dict.fromkeys(pairs))
    entries = [pairs[random.randrange(len(pairs))] for _ in range(n)]

    t = time.perf_counter()
    s1 = 0.0
    for fat, snf in entries:
        s1 += rate_per_litre(fat, snf)
    t_recalc = time.perf_counter() - t

    t = time.perf_counter()
    table = {pair: rate_per_litre(*pair) for pair in pairs}
    t_build = time.perf_counter() - t

    t = time.perf_counter()
    s2 = 0.0
    for entry in entries:
        s2 += table[entry]
    t_lookup = time.perf_counter() - t
    assert abs(s1 - s2) < 1e-6
    print(f"k={len(pairs):>4}  recalculate {t_recalc*1e3:6.1f} ms ({t_recalc/n*1e6:.3f} us/entry)  "
          f"build {t_build*1e3:.2f} ms  lookup {t_lookup*1e3:6.1f} ms ({t_lookup/n*1e6:.3f} us/entry)  "
          f"dictionary {sys.getsizeof(table)} bytes")

N = 200000
table = {(4.2, 8.7): 33.4}
print("\ntimeit, single call:")
print(f"  recalculate rate_per_litre(4.2, 8.7): {timeit.timeit('rate_per_litre(4.2, 8.7)', globals=globals(), number=N)/N*1e6:.3f} us")
print(f"  dictionary lookup table[(4.2, 8.7)]  : {timeit.timeit('table[(4.2, 8.7)]', globals=globals(), number=N)/N*1e6:.3f} us")
