"""Task 8: the Python program that matches pseudocode.txt.

Input lines (from input.txt):  litres fat snf shift      e.g.   10 3.5 8.5 M
Run:  python task08_payment.py < input.txt
"""
import sys
from milkrate import rate_per_litre, payout

entries = []
for line in sys.stdin:
    parts = line.split()
    if len(parts) == 4:
        entries.append((float(parts[0]), float(parts[1]), float(parts[2]), parts[3]))

total = 0.0
for litres, fat, snf, shift in entries:
    if litres > 0 and 2.0 <= fat <= 7.0 and 7.0 <= snf <= 10.0 and shift in ("M", "E"):
        total += payout(litres, fat, snf)
        print(f"{litres:5} L rate {rate_per_litre(fat, snf):6.2f} pay {payout(litres, fat, snf):8.2f}")
    else:
        print("Entry rejected")
print("Ten-day total:", round(total, 2))
