"""Task 8 alternative: store every entry in a list and add at the end, or keep a running total."""
import time, tracemalloc, sys

def make_entry(i):
    return 10.0 + i % 10, 3.0 + (i % 30) / 10, 8.0 + (i % 15) / 10

def amount_of(litres, fat, snf):
    return round(litres * (30.0 + round((fat - 3.5) / 0.1) * 0.40 + round((snf - 8.5) / 0.1) * 0.30), 2)

def total_with_list(n):
    amounts = []
    for i in range(n):
        amounts.append(amount_of(*make_entry(i)))
    return sum(amounts)

def total_running(n):
    total = 0.0
    for i in range(n):
        total += amount_of(*make_entry(i))
    return total

print(f"{'n':>8}{'list time':>12}{'running time':>14}{'list memory':>14}{'running memory':>16}")
for n in (6000, 60000, 600000):
    row = []
    for func in (total_with_list, total_running):
        tracemalloc.start()
        t = time.perf_counter()
        result = func(n)
        elapsed = time.perf_counter() - t
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        row.append((elapsed, peak, result))
    print(f"{n:>8}{row[0][0]*1000:>9.1f} ms{row[1][0]*1000:>11.1f} ms{row[0][1]/1024:>10.1f} KB{row[1][1]/1024:>13.2f} KB")
    assert abs(row[0][2] - row[1][2]) < 1e-6
print("\nBoth give the same total. Time is O(n) for both; space is O(n) for the list and O(1) for the running total.")
